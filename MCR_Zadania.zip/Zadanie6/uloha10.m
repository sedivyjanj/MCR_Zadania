ret=tf([7.253*10^-4 -0.0012 2.0843*10^-4],[1 0 0.3705 -0.9970],1,'Variable','z^-1')
poly=pole(ret)
absolut=abs(poly)