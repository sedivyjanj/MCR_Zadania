
%ret=tf([9.67*10^-4 -0.0019 9*10^-4],[1 0 0.4941 -1.4941],1,'Variable','z^-1')
ret = [1 0 0.4941 -1.4941]; 
poly=roots(ret)
absolut=abs(poly)