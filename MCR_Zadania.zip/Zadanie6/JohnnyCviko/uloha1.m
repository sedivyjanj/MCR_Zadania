%uloha1
%ak by nevychadzalo zmenit d vo vzorci z prednasky na d=2
b0=0;
b1=0;
b2=-510.87;
b3=1544.9;
a0=1;
a1=-1.9311;
a2=0.9311;

q0=1/(b0+b1+b2+b3)
q1=a1*q0
q2=a2*q0

p2=b2*q0
p3=b3*q0